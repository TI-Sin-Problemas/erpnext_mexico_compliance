-- begin frappe metadata
-- [frappe]
-- version = 15.70.0
-- branch = version-15
-- end frappe metadata
-- 
-- Partial Backup of Frappe Site test_site.localhost
-- Backup contains: tabWarehouse Type, tabCustomer Group
-- 
/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.11-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: mariadb    Database: _416820a39d82ac11
-- ------------------------------------------------------
-- Server version	10.6.21-MariaDB-ubu2004

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tabWarehouse Type`
--

DROP TABLE IF EXISTS `tabWarehouse Type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tabWarehouse Type` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` int(1) NOT NULL DEFAULT 0,
  `idx` int(8) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `modified` (`modified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWarehouse Type`
--

LOCK TABLES `tabWarehouse Type` WRITE;
/*!40000 ALTER TABLE `tabWarehouse Type` DISABLE KEYS */;
INSERT INTO `tabWarehouse Type` VALUES
('Transit','2025-06-16 23:25:42.259660','2025-06-16 23:25:42.259660','Administrator','Administrator',0,0,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tabWarehouse Type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabCustomer Group`
--

DROP TABLE IF EXISTS `tabCustomer Group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tabCustomer Group` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` int(1) NOT NULL DEFAULT 0,
  `idx` int(8) NOT NULL DEFAULT 0,
  `customer_group_name` varchar(140) DEFAULT NULL,
  `parent_customer_group` varchar(140) DEFAULT NULL,
  `is_group` int(1) NOT NULL DEFAULT 0,
  `default_price_list` varchar(140) DEFAULT NULL,
  `payment_terms` varchar(140) DEFAULT NULL,
  `lft` int(11) NOT NULL DEFAULT 0,
  `rgt` int(11) NOT NULL DEFAULT 0,
  `old_parent` varchar(140) DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `customer_group_name` (`customer_group_name`),
  KEY `lft` (`lft`),
  KEY `rgt` (`rgt`),
  KEY `modified` (`modified`),
  KEY `lft_rgt_index` (`lft`,`rgt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabCustomer Group`
--

LOCK TABLES `tabCustomer Group` WRITE;
/*!40000 ALTER TABLE `tabCustomer Group` DISABLE KEYS */;
INSERT INTO `tabCustomer Group` VALUES
('All Customer Groups','2025-06-16 23:25:41.231985','2025-06-16 23:25:41.231985','Administrator','Administrator',0,0,'All Customer Groups',NULL,1,NULL,NULL,1,10,'',NULL,NULL,NULL,NULL),
('Commercial','2025-06-16 23:25:41.283707','2025-06-16 23:25:41.283707','Administrator','Administrator',0,0,'Commercial','All Customer Groups',0,NULL,NULL,4,5,'All Customer Groups',NULL,NULL,NULL,NULL),
('Government','2025-06-16 23:25:41.330961','2025-06-16 23:25:41.330961','Administrator','Administrator',0,0,'Government','All Customer Groups',0,NULL,NULL,8,9,'All Customer Groups',NULL,NULL,NULL,NULL),
('Individual','2025-06-16 23:25:41.263695','2025-06-16 23:25:41.263695','Administrator','Administrator',0,0,'Individual','All Customer Groups',0,NULL,NULL,2,3,'All Customer Groups',NULL,NULL,NULL,NULL),
('Non Profit','2025-06-16 23:25:41.307469','2025-06-16 23:25:41.307469','Administrator','Administrator',0,0,'Non Profit','All Customer Groups',0,NULL,NULL,6,7,'All Customer Groups',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tabCustomer Group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-17  6:13:08
